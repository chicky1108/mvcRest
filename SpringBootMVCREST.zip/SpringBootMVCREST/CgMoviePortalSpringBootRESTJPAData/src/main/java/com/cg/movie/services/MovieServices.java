package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.exceptions.MovieNotFoundException;

public interface MovieServices
{
     public Movie acceptMovieDetails(Movie movie);
     
     public Songs acceptSongDetails(String movieName,Songs songs) throws MovieNotFoundException;
     
     public Movie getMovieDetails(String movieName) throws MovieNotFoundException;
     
     public List<Movie> getAllMovieDetails();
     
     public boolean removeMovieDetails(String movieName)throws MovieNotFoundException;
     
     public List<Songs> getMovieAllSongsList(String movieName)throws MovieNotFoundException;
}
