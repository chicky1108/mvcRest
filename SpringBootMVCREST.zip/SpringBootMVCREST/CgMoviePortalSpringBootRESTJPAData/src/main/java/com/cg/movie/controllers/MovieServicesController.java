package com.cg.movie.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.services.MovieServices;


@Controller
public class MovieServicesController 
{
    @Autowired
    MovieServices movieServices;
    
    @RequestMapping(value="/acceptMovieDetails", method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<String> getAcceptMovieDetails(@ModelAttribute Movie movie)
    {
    	movie = movieServices.acceptMovieDetails(movie);
    	return new ResponseEntity<String>("Movie Details Accepted Successfully!\n" + movie,HttpStatus.OK);
    }
    
    @RequestMapping(value="/acceptSongDetails", method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<String> getAcceptSongDetails(@RequestParam String movieName,@ModelAttribute Songs songs) throws MovieNotFoundException
    {
    	songs = movieServices.acceptSongDetails(movieName,songs);
    	return new ResponseEntity<String>("Movie Details Accepted Successfully!\n" + songs.getSongId(),HttpStatus.OK);
    }
    
    @RequestMapping(value= {"/getMovieDetails/{movieName}"},method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,
    		headers="Accept=application/json")
    public ResponseEntity<Movie> getMovieDetailsPathParam(@PathVariable(value="movieName") String movieName)throws MovieNotFoundException
    {
    	Movie movie = movieServices.getMovieDetails(movieName);
    	return new ResponseEntity<Movie>(movie,HttpStatus.OK);
    }
    
    @RequestMapping(value= {"/getAllMovieDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
    		headers="Accept=application/json")
    public ResponseEntity<List<Movie>> getAllMovieDetailsPathParam()
    {
    	return new ResponseEntity<List<Movie>>(movieServices.getAllMovieDetails(),HttpStatus.OK);
    }
    
    @RequestMapping(value= {"/getAllMovieSongsDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
    		headers="Accept=application/json")
    public ResponseEntity<List<Songs>> getAllMovieSongsDetailsPathParam(@RequestParam String movieName)throws MovieNotFoundException
    {
    	return new ResponseEntity<List<Songs>>(movieServices.getMovieAllSongsList(movieName),HttpStatus.OK);
    }
}
