package com.cg.product.services;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundException;

public interface IProductService 
{
    public Product createProduct(Product product);
    
    public boolean updateProduct(String productId,Product product) throws ProductNotFoundException;
    
    public boolean deleteProduct(String productId) throws ProductNotFoundException;
    
    public List<Product> viewProducts();
    
    public Product findProduct(String productId) throws ProductNotFoundException;
}