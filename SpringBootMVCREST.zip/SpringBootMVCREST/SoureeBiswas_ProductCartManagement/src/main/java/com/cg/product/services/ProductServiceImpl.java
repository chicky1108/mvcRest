package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.daoservices.IProductRepo;
import com.cg.product.exceptions.ProductNotFoundException;

@Component("productServices")
public class ProductServiceImpl implements IProductService
{
	@Autowired
	IProductRepo productDAO;

	@Override
	public Product createProduct(Product product) {
	    product = productDAO.save(product);
		return product;
	}

	@Override
	public boolean updateProduct(String productId, Product product) throws ProductNotFoundException {
		findProduct(productId);
		product.setId(productId);
		productDAO.save(product);
		return true;
	}
	@Override
	public boolean deleteProduct(String productId) throws ProductNotFoundException{
		Product product = productDAO.findById(productId).orElseThrow(()->new ProductNotFoundException("Sorry Product Not Found"));
		productDAO.deleteById(productId);
		return true;
	}

	@Override
	public List<Product> viewProducts() {
	   return productDAO.findAll();
	}

	@Override
	public Product findProduct(String productId) throws ProductNotFoundException{
		Product product = productDAO.findById(productId).orElseThrow(()->new ProductNotFoundException("Sorry Product Not Found"));
		return product;
	}
    
}
