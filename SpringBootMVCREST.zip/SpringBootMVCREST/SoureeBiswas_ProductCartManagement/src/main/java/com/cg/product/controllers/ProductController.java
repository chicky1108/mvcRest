package com.cg.product.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundException;
import com.cg.product.services.IProductService;

@Controller
public class ProductController 
{
    @Autowired
    IProductService productServices;
    
   @RequestMapping(value="/createProduct", method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
   public ResponseEntity<String> getCreateProductDetails(@ModelAttribute Product product)
   {
	   product = productServices.createProduct(product);
   	   return new ResponseEntity<String>("Product Details Accepted Successfully!\n" + product,HttpStatus.OK);
   }
   
   @RequestMapping(value="/updateProduct",method=RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE,
   		headers="Accept=application/json")
   public ResponseEntity<Boolean> getMovieDetailsPathParam(@RequestParam String productId, @ModelAttribute Product product)throws ProductNotFoundException
   {
   	boolean result = productServices.updateProduct(productId,product);
   	return new ResponseEntity<Boolean>(result,HttpStatus.OK);
   }
   
   @RequestMapping(value= {"/products"},method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,
   		headers="Accept=application/json")
   public ResponseEntity<Product> getViewProductDetails(@RequestParam String productId)throws ProductNotFoundException
   {
   	Product product = productServices.findProduct(productId);
   	return new ResponseEntity<Product>(product,HttpStatus.OK);
   }
   
   @RequestMapping(value= {"/findAllProducts"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
   		headers="Accept=application/json")
   public ResponseEntity<List<Product>> getFindAllProductDetails()
   {
   	return new ResponseEntity<List<Product>>(productServices.viewProducts(),HttpStatus.OK);
   }
   
   @RequestMapping(value= {"/deleteProduct"},method=RequestMethod.DELETE, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
   public ResponseEntity<String> getDeleteProductDetails(@RequestParam String productId)throws ProductNotFoundException
   {
	   productServices.deleteProduct(productId);
   	   return new ResponseEntity<>("Product details deleted successfully of Product Id:- " + productId,HttpStatus.OK);
   }
   
}